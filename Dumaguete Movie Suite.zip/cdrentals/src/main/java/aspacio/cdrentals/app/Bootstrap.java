/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aspacio.cdrentals.app;

import aspacio.cdrentals.activity.Edit;
import aspacio.cdrentals.activity.MainWindow;
import aspacio.cdrentals.activity.Rent;
import aspacio.cdrentals.dbinterface.CatalogDAO;
import aspacio.cdrentals.dbinterface.InformationDAO;
import java.sql.SQLException;

/**
 *
 * @author Phoenix Eve Aspacio
 */
public class Bootstrap {
    
    public static MainWindow MainWindow = new MainWindow();
    public static Rent Rent = new Rent();
    public static CatalogDAO CatalogDAO = new CatalogDAO();
    public static InformationDAO InformationDAO = new InformationDAO();
    public static Edit Edit = new Edit();
    
    public static void main(String args[]) throws SQLException {
        MainWindow.setVisible(true);
        Rent.setVisible(true);
        Edit.setVisible(true);
//        CatalogDAO.initCdCatalog();
    }
    
    
}
