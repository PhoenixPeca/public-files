/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aspacio.cdrentals.dbinterface;

import aspacio.cdrentals.app.Bootstrap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import aspacio.cdrentals.app.DBConnect;
import aspacio.cdrentals.app.DBUtil;
import java.sql.ResultSetMetaData;
import java.util.Arrays;


/**
 *
 * @author Phoenix Eve Aspacio
 */
public class InformationDAO {
    private Connection connection;
    private Statement statement;
    
    public InformationDAO() {}
    
    public void initCdInformation(String cd_id) throws SQLException {
        String query = "SELECT * FROM cd_information WHERE cd_id = "+cd_id+" LIMIT 1";
        ResultSet rs = null;
        try {
            String columnValue[] = new String[8];
            connection = DBConnect.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            String text = "Information data not available.";
            while (rs.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                    columnValue[i-1] = rs.getString(i);
                }
                text = "Synopsis: "+columnValue[1]+"\n\nDirector: "+columnValue[2]+
                        "\n\nWriters: "+columnValue[3]+"\n\nStars: "+columnValue[4];
            }
            Bootstrap.MainWindow.setTextInformationPane(text);
        } finally {
            DBUtil.close(rs);
            DBUtil.close(statement);
            DBUtil.close(connection);
        }
    }
}
