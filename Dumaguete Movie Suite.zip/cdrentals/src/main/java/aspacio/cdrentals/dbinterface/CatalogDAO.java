/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aspacio.cdrentals.dbinterface;

import aspacio.cdrentals.app.Bootstrap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import aspacio.cdrentals.app.DBConnect;
import aspacio.cdrentals.app.DBUtil;
import java.sql.ResultSetMetaData;
import java.util.Arrays;


/**
 *
 * @author Phoenix Eve Aspacio
 */
public class CatalogDAO {
    private Connection connection;
    private Statement statement;
    
    public CatalogDAO() {}
    
    public void initCdCatalog() throws SQLException {
        String query = "SELECT * FROM cd_catalog";
        ResultSet rs = null;
        try {
            Bootstrap.MainWindow.clearCatalog();
            String columnValue[] = new String[8];
            connection = DBConnect.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            while (rs.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                    columnValue[i-1] = rs.getString(i);
                }
                Bootstrap.MainWindow.addCatalogItem(columnValue[0], columnValue[1], columnValue[2], columnValue[3], columnValue[4]+" minutes", columnValue[5], columnValue[6]+" / day", columnValue[7]);
                columnValue = new String[8];
            }
        } finally {
            DBUtil.close(rs);
            DBUtil.close(statement);
            DBUtil.close(connection);
        }
    }
}
